# CS4200

## Installation

```
make
```

## Instructor Required Installs


```
yum -y install texlive-latex
yum -y install texlive texlive-*.noarch
```

## Usage

When launching a container for the first time:

```
docker run -it --name CS4200 -v $HOME/CS4200:/home/$USER/CS4200 cs4200 su - $USER
```

When relaunching a container:

```
docker restart CS4200
docker exec -it CS4200 su - $USER
```