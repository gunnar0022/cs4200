# Valgrind

## Build

```
make
```

## Usage

Modify the following library paths:

* `PATH`: `export PATH=$(PATH):${HOME}/bin/valgrind/bin`
* `LD_LIBRARY_PATH`: `export LD_LIBRARY_PATH=${HOME}/bin/valgrind/libexec/valgrind`
